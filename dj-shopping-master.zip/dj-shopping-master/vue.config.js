// vue.config.js
module.exports = {
    // options...
    assetsDir: "static"
}